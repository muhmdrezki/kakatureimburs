<?php  
 //fetch.php  
    echo $_SESSION['nama'];
?>