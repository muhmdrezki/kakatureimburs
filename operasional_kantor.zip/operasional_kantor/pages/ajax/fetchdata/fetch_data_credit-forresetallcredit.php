   <?php  
     error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
      $output = '';  
      $output .= ' 
      <label><h4>   Konfirmasi Bayar?</h4></label>
      <br>';
      echo $output;   
 ?>