<?php  
 //fetch.php  
    session_start();
    echo $_SESSION['jabatan'];
?>