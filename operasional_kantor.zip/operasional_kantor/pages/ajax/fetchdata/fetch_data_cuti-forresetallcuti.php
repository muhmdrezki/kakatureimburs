   <?php  
     error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
      $output = '';  
      $output .= ' 
      <label><h4>   Anda yakin akan mereset semua cuti terpakai anggota?</h4></label>
      <br>';
      echo $output;   
 ?>